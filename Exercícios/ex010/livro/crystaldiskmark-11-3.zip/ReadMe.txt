/*---------------------------------------------------------------------------*/
//      Product : CrystalDiskMark 8
//       Author : hiyohiyo
//         Mail : hiyohiyo@crystalmark.info
//          Web : https://crystalmark.info/
//      License : The MIT License
/*---------------------------------------------------------------------------*/

== Standard Edition ==
DiskMark32.exe   : 32bit (x86)
DiskMark64.exe   : 64bit (x64)
DiskMarkA64.exe  : 64bit (ARM64)

== Shizuku Edition ==
DiskMark32S.exe  : 32bit (x86)
DiskMark64S.exe  : 64bit (x64)
DiskMarkA64S.exe : 64bit (ARM64)

== OS ==
OK: Windows XP/Vista/7/8/8.1/10/2003/2008/2012/2016/2019
NG: Windows 95/98/Me/NT4/2000